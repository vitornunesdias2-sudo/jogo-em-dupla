extends Area2D


var jogador_perto = false


func _on_body_entered(body):
	if body.is_in_group("jogador"):
		jogador_perto = true


func _on_body_exited(body):
	if body.is_in_group("jogador"):
		jogador_perto = false
