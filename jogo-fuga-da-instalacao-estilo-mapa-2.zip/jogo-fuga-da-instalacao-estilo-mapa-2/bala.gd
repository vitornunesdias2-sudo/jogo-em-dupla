extends Area2D
# Tiro do jogador ou da torreta

var direcao = Vector2.RIGHT
var velocidade = 200.0
var do_jogador = true
var vida_util = 2.0


func _ready():
	if do_jogador:
		collision_mask = 5   # parede (1) e inimigos (4)
	else:
		collision_mask = 3   # parede (1) e jogador (2)


func _draw():
	if do_jogador:
		draw_circle(Vector2.ZERO, 1.5, Color(1.0, 0.9, 0.3))
	else:
		draw_circle(Vector2.ZERO, 2.0, Color(1.0, 0.3, 0.2))


func _process(delta):
	if get_tree().current_scene.estado != "jogando":
		return

	position += direcao * velocidade * delta
	vida_util -= delta
	if vida_util <= 0:
		queue_free()


func _on_body_entered(body):
	if body.is_in_group("inimigos"):
		body.levar_dano(1)
	elif body.is_in_group("jogador"):
		body.levar_dano(8)
	# se nao era nenhum dos dois, bateu na parede
	queue_free()
