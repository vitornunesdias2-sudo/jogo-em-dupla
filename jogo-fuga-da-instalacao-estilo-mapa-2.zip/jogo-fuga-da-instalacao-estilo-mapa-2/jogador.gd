extends CharacterBody2D


const CenaBala = preload("res://bala.tscn")

signal mensagem(texto)
signal morreu

@onready var animacao = $AnimatedSprite2D
@onready var camera = $Camera2D

var ativo = true
var velocidade = 70.0
var vida = 100.0
var vida_max = 100.0
var municao = 20
var baterias = 0
var cartao_azul = false
var cartao_vermelho = false
var tempo_tiro = 0.0
var tempo_dano = 0.0


func _physics_process(delta):
	if not ativo:
		velocity = Vector2.ZERO
		return

	# movimento
	var dir = Vector2.ZERO
	if Input.is_key_pressed(KEY_W):
		dir.y -= 1
	if Input.is_key_pressed(KEY_S):
		dir.y += 1
	if Input.is_key_pressed(KEY_A):
		dir.x -= 1
	if Input.is_key_pressed(KEY_D):
		dir.x += 1
	velocity = dir.normalized() * velocidade
	move_and_slide()

	# olha pro lado do mouse
	var mouse = get_global_mouse_position()
	animacao.flip_h = mouse.x < global_position.x

	# piscar vermelho quando leva dano
	tempo_dano -= delta
	if tempo_dano > 0:
		animacao.modulate = Color(1, 0.3, 0.3)
	else:
		animacao.modulate = Color.WHITE

	# tiro
	tempo_tiro -= delta
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and tempo_tiro <= 0:
		atirar(mouse)


func atirar(alvo):
	if municao <= 0:
		tempo_tiro = 0.5
		mensagem.emit("Sem munição!")
		return
	municao -= 1
	tempo_tiro = 0.2
	var bala = CenaBala.instantiate()
	bala.do_jogador = true
	bala.direcao = (alvo - global_position).normalized()
	bala.position = global_position + bala.direcao * 8
	get_tree().current_scene.add_child(bala)


func levar_dano(valor):
	if not ativo:
		return
	vida -= valor
	tempo_dano = 0.15
	if vida <= 0:
		vida = 0
		ativo = false
		morreu.emit()



func pegar(tipo):
	if tipo == "medkit":
		if vida >= vida_max:
			return false
		vida = min(vida_max, vida + 35)
		mensagem.emit("Kit de cura: +35 de vida")
	elif tipo == "municao":
		if municao >= 99:
			return false
		municao = min(99, municao + 10)
		mensagem.emit("Munição: +10")
	elif tipo == "bateria":
		baterias += 1
		mensagem.emit("Bateria coletada (" + str(baterias) + ")")
	elif tipo == "cartao_azul":
		cartao_azul = true
		mensagem.emit("Cartão de acesso AZUL coletado!")
	elif tipo == "cartao_vermelho":
		cartao_vermelho = true
		mensagem.emit("Cartão de acesso VERMELHO coletado!")
	return true
