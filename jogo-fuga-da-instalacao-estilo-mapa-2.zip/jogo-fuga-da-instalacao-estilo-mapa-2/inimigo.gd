extends CharacterBody2D
# Inimigos: robo (patrulha), bicho (rapido) e torreta (fica parada e atira)

const CenaBala = preload("res://bala.tscn")

@export_enum("robo", "bicho", "torreta") var tipo = "robo"
@export var ponto_b = Vector2.ZERO   # fim da patrulha (o comeco e onde o inimigo foi colocado no mapa)

@onready var animacao = $AnimatedSprite2D

var ponto_a = Vector2.ZERO
var indo_para_b = true
var vida = 3
var vida_max = 3
var velocidade = 28.0
var alcance = 70.0
var memoria = 0.0
var tempo_ataque = 0.0
var encostando = false
var jogador


func _ready():
	ponto_a = global_position
	animacao.play(tipo)

	if tipo == "robo":
		vida = 3
		velocidade = 28.0
		alcance = 70.0
	elif tipo == "bicho":
		vida = 2
		velocidade = 50.0
		alcance = 90.0
	else:
		vida = 5

	vida_max = vida
	tempo_ataque = randf()


func _physics_process(delta):
	if jogador == null or not is_instance_valid(jogador):
		jogador = get_tree().get_first_node_in_group("jogador")
	if jogador == null or not jogador.ativo:
		velocity = Vector2.ZERO
		return

	tempo_ataque -= delta
	memoria -= delta
	var para_jogador = jogador.global_position - global_position
	var distancia = para_jogador.length()

	# torreta so atira
	if tipo == "torreta":
		animacao.flip_h = para_jogador.x < 0
		if distancia < 110 and tempo_ataque <= 0:
			tempo_ataque = 1.5
			atirar(para_jogador.normalized())
		return

	# viu o jogador? persegue
	if distancia < alcance:
		memoria = 2.0

	var dir = Vector2.ZERO
	var vel = velocidade
	if memoria > 0:
		dir = para_jogador.normalized()
	else:
		# patrulha entre os pontos A e B
		var destino = ponto_a
		if indo_para_b:
			destino = ponto_b
		if global_position.distance_to(destino) < 3:
			indo_para_b = not indo_para_b
		else:
			dir = (destino - global_position).normalized()
			vel = velocidade * 0.6

	velocity = dir * vel
	move_and_slide()
	if dir.x != 0:
		animacao.flip_h = dir.x < 0

	# encostou no jogador = dano
	if encostando and tempo_ataque <= 0:
		tempo_ataque = 0.8
		jogador.levar_dano(10)


func atirar(direcao):
	var bala = CenaBala.instantiate()
	bala.do_jogador = false
	bala.velocidade = 90.0
	bala.direcao = direcao
	bala.position = global_position + direcao * 8
	get_tree().current_scene.add_child(bala)


func levar_dano(valor):
	if vida <= 0:
		return
	vida -= valor
	memoria = 3.0
	animacao.modulate = Color(1, 0.4, 0.4)
	get_tree().create_timer(0.1).timeout.connect(voltar_cor)
	if vida <= 0:
		# as vezes solta municao
		if tipo != "torreta" and randf() < 0.3:
			get_tree().current_scene.criar_item("municao", global_position)
		queue_free()


func voltar_cor():
	if is_instance_valid(animacao):
		animacao.modulate = Color.WHITE


func _on_area_contato_body_entered(body):
	if body.is_in_group("jogador"):
		encostando = true


func _on_area_contato_body_exited(body):
	if body.is_in_group("jogador"):
		encostando = false
