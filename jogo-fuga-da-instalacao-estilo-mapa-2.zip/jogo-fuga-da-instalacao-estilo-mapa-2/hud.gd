extends CanvasLayer
# Tela: barra de vida, textos e os paineis de pausa e fim de jogo

signal continuar
signal reiniciar
signal voltar_menu

@onready var barra_vida = $GrupoHud/BarraVida
@onready var lbl_vida = $GrupoHud/LblVida
@onready var lbl_info = $GrupoHud/LblInfo
@onready var lbl_cartoes = $GrupoHud/LblCartoes
@onready var lbl_obj = $GrupoHud/LblObj
@onready var lbl_dica = $GrupoHud/LblDica
@onready var lbl_msg = $GrupoHud/LblMsg
@onready var painel_pausa = $PainelPausa
@onready var painel_fim = $PainelFim
@onready var lbl_titulo_fim = $PainelFim/Centro/Caixa/LblTitulo
@onready var lbl_texto_fim = $PainelFim/Centro/Caixa/LblTexto

var tempo_msg = 0.0


func _process(delta):
	if tempo_msg > 0:
		tempo_msg -= delta
		if tempo_msg <= 0:
			lbl_msg.text = ""


func mostrar_msg(texto):
	lbl_msg.text = texto
	tempo_msg = 3.0


func mostrar_dica(texto):
	lbl_dica.text = texto


func atualizar(j, objetivo):
	barra_vida.size.x = 80.0 * j.vida / j.vida_max
	if j.vida > 35:
		barra_vida.color = Color(0.2, 0.8, 0.3)
	else:
		barra_vida.color = Color(0.9, 0.2, 0.2)
	lbl_vida.text = "VIDA " + str(int(j.vida))
	lbl_info.text = "Munição: " + str(j.municao) + "   Baterias: " + str(j.baterias) + "/2"
	var texto = "Cartões: "
	if j.cartao_azul:
		texto += "[AZUL] "
	else:
		texto += "- "
	if j.cartao_vermelho:
		texto += "[VERMELHO]"
	else:
		texto += "-"
	lbl_cartoes.text = texto
	lbl_obj.text = objetivo


func mostrar_pausa(valor):
	painel_pausa.visible = valor


func mostrar_fim(titulo, texto):
	lbl_titulo_fim.text = titulo
	lbl_texto_fim.text = texto
	painel_fim.visible = true


func _on_botao_continuar_pressed():
	continuar.emit()


func _on_botao_reiniciar_pressed():
	reiniciar.emit()


func _on_botao_menu_pressed():
	voltar_menu.emit()
