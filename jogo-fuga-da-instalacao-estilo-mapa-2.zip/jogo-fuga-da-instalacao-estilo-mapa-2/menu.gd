extends Control

@onready var principal = $Principal
@onready var creditos = $Creditos


func _on_botao_jogar_pressed() -> void:
	get_tree().change_scene_to_file("res://jogo.tscn")


func _on_botao_creditos_pressed() -> void:
	principal.visible = false
	creditos.visible = true


func _on_botao_voltar_pressed() -> void:
	creditos.visible = false
	principal.visible = true


func _on_botao_sair_pressed() -> void:
	get_tree().quit()
