extends Area2D
#

@export_enum("medkit", "municao", "bateria", "cartao_azul", "cartao_vermelho") var tipo = "medkit"

@onready var animacao = $AnimatedSprite2D


func _ready():
	if tipo == "cartao_azul":
		animacao.play("cartao")
		animacao.modulate = Color(0.4, 0.6, 1.0)
	elif tipo == "cartao_vermelho":
		animacao.play("cartao")
		animacao.modulate = Color(1.0, 0.35, 0.35)
	else:
		animacao.play(tipo)


func _on_body_entered(body):
	if body.is_in_group("jogador") and body.ativo:
		if body.pegar(tipo):
			queue_free()
