extends Node2D


const CenaItem = preload("res://item.tscn")

@onready var parede = $Mapa/Node2D/parede
@onready var jogador = $Jogador
@onready var saida = $Saida
@onready var itens = $Itens
@onready var hud = $Hud

var estado = "jogando"   # jogando, pausa, vitoria, derrota
var tempo = 0.0


func _ready():
	
	var area = parede.get_used_rect()
	var tam = parede.tile_set.tile_size
	var canto = parede.to_global(Vector2(area.position * tam))
	jogador.camera.limit_left = int(canto.x)
	jogador.camera.limit_top = int(canto.y)
	jogador.camera.limit_right = int(canto.x) + area.size.x * tam.x
	jogador.camera.limit_bottom = int(canto.y) + area.size.y * tam.y

	hud.mostrar_msg("Onde eu estou...? Preciso achar a saída.")



func criar_item(tipo, pos):
	var i = CenaItem.instantiate()
	i.tipo = tipo
	i.position = pos
	itens.add_child.call_deferred(i)




func pausar():
	estado = "pausa"
	jogador.ativo = false
	hud.mostrar_pausa(true)


func continuar():
	estado = "jogando"
	jogador.ativo = true
	hud.mostrar_pausa(false)


func vitoria():
	estado = "vitoria"
	jogador.ativo = false
	var texto = "Você conseguiu fugir da instalação!\nTempo: %02d:%02d" % [floori(tempo / 60.0), int(tempo) % 60]
	hud.mostrar_fim("VOCÊ ESCAPOU!", texto)


func derrota():
	estado = "derrota"
	hud.mostrar_fim("VOCÊ MORREU", "A instalação foi o seu último lugar...")


func reiniciar():
	get_tree().reload_current_scene()


func ir_para_menu():
	get_tree().change_scene_to_file("res://menu.tscn")




func _process(delta):
	if estado != "jogando":
		return
	tempo += delta
	hud.atualizar(jogador, texto_objetivo())
	if saida.jogador_perto:
		hud.mostrar_dica("[E] Usar a saída")
	else:
		hud.mostrar_dica("")


func texto_objetivo():
	if not jogador.cartao_azul or not jogador.cartao_vermelho:
		return "Objetivo: ache os 2 cartões de acesso"
	if jogador.baterias < 2:
		return "Objetivo: junte 2 baterias"
	return "Objetivo: vá até a saída (lado direito) e aperte E"


func tentar_saida():
	if not saida.jogador_perto:
		return
	var falta = PackedStringArray()
	if not jogador.cartao_azul:
		falta.append("cartão azul")
	if not jogador.cartao_vermelho:
		falta.append("cartão vermelho")
	if jogador.baterias < 2:
		falta.append("2 baterias")
	if falta.size() > 0:
		hud.mostrar_msg("A saída não abre. Falta: " + ", ".join(falta))
	else:
		vitoria()


func _input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			if estado == "jogando":
				pausar()
			elif estado == "pausa":
				continuar()
		elif event.keycode == KEY_E and estado == "jogando":
			tentar_saida()
